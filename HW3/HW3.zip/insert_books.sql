use mydb;

INSERT INTO Books(Title, NumPages, PubDate, Friends_ID) VALUES('Learning Python', 752, '2007-10-29', 2);

INSERT INTO Books(Title, NumPages, PubDate) VALUES('The Pragmatic Programmer', 352, '1999-10-30');

INSERT INTO Books(Title, NumPages, PubDate, Friends_ID) VALUES('Pragmatic Thinking and Learning: Refactor Your Wetware (Pragmatic Programmers)',
    288, '2010-09-04', 2);

INSERT INTO Books(Title, NumPages, PubDate) VALUES('Agile Web Development with Rails', 480, '2011-03-31');

INSERT INTO Books(Title, NumPages, PubDate, Friends_ID) VALUES('Django 1.0 Website Development', 272, '2009-03-10', 2);

INSERT INTO Books(Title, NumPages, PubDate, Friends_ID) VALUES('The Definitive Guide to Django: Web Development Done Right', 
    536, '2009-07-08', 3);

INSERT INTO Books(Title, NumPages, PubDate) VALUES('Programming Python', 1632, '2011-01-07');

INSERT INTO Books(Title, NumPages, PubDate) VALUES('Understanding the Linux Kernel', 944, '2005-11-10');

INSERT INTO Books(Title, NumPages, PubDate) VALUES('Linux Kernel in a Nutshell', 198, '2006-12-14');

INSERT INTO Books(Title, NumPages, PubDate, Friends_ID) VALUES('Programming the Semantic Web', 304, '2009-03-10', 1);
