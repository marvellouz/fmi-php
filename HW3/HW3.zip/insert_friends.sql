use mydb;

insert into Friends(FirstName, LastName, Phone) values('Любомир', 'Попов', '012345678');

insert into Friends(FirstName, LastName, Phone) values('Филип', 'Атанасов', '919875678');

insert into Friends(FirstName, LastName, Phone) values('Димка', 'Вардина', '459635678');